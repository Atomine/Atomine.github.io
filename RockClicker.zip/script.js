var score = 0;
var rock = 0;


function add() {
  score = score + 1;
  document.getElementById("scoretext").innerHTML = "score: " + score;
}


function upgrade_rock() {
  if (score >= 100) {
    rock = rock + 1;
    document.getElementById("rocktext").innerHTML = "Pet Rocks: " + rock;
    score = score - 100;
    document.getElementById("scoretext").innerHTML = "score: " + score;
  }
}